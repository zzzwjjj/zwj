<template>
    <div>历史分析</div>
</template>
